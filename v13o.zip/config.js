module.exports = {
	token: "nope",
	support: {
		id: "862922438182567976", 
		logs: "869065559759781888", 
		message : "869065559759781888"
	},
	mongoDB: "nope", // The URl of the mongodb database
	prefix: "d-", 
	embed: {
		color: "#87cefa", 
		footer: "mDefender | 伺服器保護" 
	},
	defaultLanguage: "Chinese", 
	owner: ["847761781409447947"],
	Spotify : {
		ClientID : "bec1483253474018904bc956a50bac72",
		ClientSecret : "763b8b1c8b314151857c830ccf4d2400"
	},
	Lavalink: {
		id : "Main",
		host : "localhost",
		pass : "lmaoyueyuebot2008040719830102",
		port : 2333,
		secure: false, // Set this to true if the lavalink uses SSL or you're hosting lavalink on repl.it
	},
	apiKeys: {
		// FORTNITE FNBR: https://fnbr.co/api/docs
		fortniteTRN: "8d89f280-a581-4406-9829-73c4378582e1",
		// DBL: https://discordbots.org/api/docs#mybots
		dbl: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY1MTY5MjkyNzA3MjA3NTc4NyIsImJvdCI6dHJ1ZSwiaWF0IjoxNTk1NzgyODU4fQ.CJMR6SoDQFrhh7BO4XDB9-WwFcFCao9wJovfGGwjfUc",
		// AMETHYSTE: https://api.amethyste.moe
		amethyste: "a6716f461244b8759857ab8a675129cdd510d0a39f729124185462377c5f983a6188cf9c6beeabbfca37edb92a0f2ec868cd3346d1dee70911e9c8e74474e3cb",

		osu: "1597f6e29f15565e63021ae9dcf764f8abb36c4e",

		dblStats : "11cd1df6fe58d1bcfeaa1e61343be73137668485972f948ecaaac9f897117ff45b6756d01813c8f87f8726c2",

		hypixel : "007a9363-0f3f-4496-8353-0c5762ec2f88",

		CLARIFAI : "369cc61e00404816ae2428488ec10cf7",

		twitch: "0i90eg3chxy6tmdts7412cn5zl2vgl",
		
		darkbot : "uGVjGrANkulBNeAHOZImyoPv"
	},
	status: [
        {
            name: "Bot is Current Test Version ",
            type: "LISTENING"
        }
	],
	webhook:{
		id : "929582549582377020",
		token : "BZeO0wegWcO75rLk7FFU7RSIOTUBIOxGkL3wVmfJSA3qeYLRG2xxP-tGtEtIx3udwBiP",
		//https://discord.com/api/webhooks/929582549582377020/BZeO0wegWcO75rLk7FFU7RSIOTUBIOxGkL3wVmfJSA3qeYLRG2xxP-tGtEtIx3udwBiP
	}
};
