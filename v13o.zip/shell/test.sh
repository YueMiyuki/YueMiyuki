echo Testing commands...
cd ..
node test.js
if [ "$?" != "0" ]
then
    echo There was an problem in some commands... Exiting...
    exit 1
fi
echo Testing main file...
node --check chino.js
exit 0
