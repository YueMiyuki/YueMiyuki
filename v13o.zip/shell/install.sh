echo "Installing pm2"
npm i pm2 -g --loglevel error
echo "Installed pm2"
echo
echo "These packages are outdated:"
npm outdated
echo "Build finished."
