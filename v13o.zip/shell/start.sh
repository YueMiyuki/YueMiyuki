echo Starting...
cd ..
pm2 link ph0lfgkmtiqm3qr ezezhcr789f381d
pm2-runtime start process.json
