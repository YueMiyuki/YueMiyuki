const mongodb = require('mongodb');
const MongoDB = "nope"
const mongo = new mongodb.MongoClient(MongoDB, {
	useUnifiedTopology: true,
	useNewUrlParser: true,
	});
try {
	mongo.connect();
} catch (error) {
	console.error(error);
}
module.exports = mongo;